
void myFgets(char buffer[], int limite ,FILE* archivo);
int Val_GetString(char destino[], char mensaje[],char mensajeError[],int intentos,int limite);

int val_validarletra(char buffer[]);

int val_getUnsignedInt(char destino[], char mensaje[],char mensajeError[],int intentos,int limite);

int val_validarUnsignedInt(char buffer[]);

int Val_GetStringNumeros(char destino[], char mensaje[],char mensajeError[],int intentos,int limite);

int esNumerico(char str[]);

